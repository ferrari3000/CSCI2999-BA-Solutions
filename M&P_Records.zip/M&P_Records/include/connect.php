<!-- Connects to the database  -->

<?php

$con = new mysqli('localhost', 'root', '', 'recordstore');

?>