drop database if exists recordstore;
create database if not exists recordstore;

use recordstore;

DROP TABLE IF EXISTS artist;

CREATE TABLE artist (
  artist_id int(10) unsigned primary key auto_increment,
  artist_name varchar(50) CHARACTER SET utf8 NOT NULL,
  created_date datetime default current_timestamp
  );


insert into artist (artist_name) values ('Local Natives');
set @artistId = (select artist_id from artist where artist_name = 'Local Natives');


DROP TABLE IF EXISTS albums;

CREATE TABLE albums (
  album_id int(10) unsigned primary key auto_increment,
  album_name nvarchar(100) not null,
  artist_id int unsigned,
  cost decimal(5,2) NOT NULL,
  created_date datetime default current_timestamp,
  last_mod_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  stock int(10) unsigned DEFAULT NULL
  );

insert into albums (album_name, artist_id, cost, stock) 
values ('Gorilla Manor', @artistId, 7.50, 3), ('Hummingbird', @artistId, 9.50, 2),('Sunlit Youth', @artistId, 11.50, 10);

# join both tables to get data
select * from albums al join artist a on al.artist_id = a.artist_id;
