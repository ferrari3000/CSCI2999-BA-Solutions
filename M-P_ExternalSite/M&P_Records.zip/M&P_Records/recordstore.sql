drop database if exists recordstore;
create database if not exists recordstore;

use recordstore;

DROP TABLE IF EXISTS artist;

CREATE TABLE artist (
  artistID int(10) primary key auto_increment, 
  artistName varchar(100) NOT NULL,
  created_date datetime default current_timestamp
  );


DROP TABLE IF EXISTS album;

CREATE TABLE album (
  albumID int(10) primary key auto_increment, 
  artistID int(10),
  albumName varchar(100) not null,
  cost DECIMAL(5 , 2 ) NOT NULL,
  created_date datetime default current_timestamp,
  foreign key (artistID) references artist(artistID)
  );


insert into artist (ArtistName) values ('Local Natives');
set @artistID = (select artistID from artist where artistName = 'Local Natives');

insert into album (albumName, artistID, cost) 
values ('Gorilla Manor', @artistID, 10.5), ('Hummingbird', @artistID, 12.5),('Sunlit Youth', @artistID, 19.5);


insert into artist (ArtistName) values ('Metallica');
set @artistID = (select artistID from artist where artistName = 'Metallica');

insert into album (albumName, artistID, cost) 
values ('Load', @artistID, 5.5), ('Reload', @artistID, 5.5),('Black Album', @artistID, 10.5),
('Kill em All', @artistID, 11.5),('Rid The Lightning', @artistID, 8.5),('St. Anger', @artistID, .5);

# join both tables to get data
#select * from artist a join album al on al.artistID = a.artistID; 
SELECT artistName, albumName, cost FROM album inner join artist on album.artistID = artist.artistID;      