<?php
	include 'include/connect.php';
    $id = $_GET['id'];
    $q = "delete from album where albumID = $id";
    $result = $con->query($q);

    if (!$result) {
    	echo "ERROR: " . $con->error;
    }
    else{
    	header('Location: index.php');
    }

?>