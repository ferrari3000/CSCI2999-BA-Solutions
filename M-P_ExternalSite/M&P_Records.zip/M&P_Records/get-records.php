<!doctype html>
<link rel="stylesheet" href="include/style.css" />
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Records</title>
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver"</script>
<script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Main Container -->
  <!-- Logo Section -->
  <section class="hero" id="hero">
    <div> <a href="index.php"> <img id="logo" src="img/m_and_p_logo.png" alt="M & P Logo"></a> <img id="slogan" src="img/m_and_p_slogan.png" alt="M & P Slogan"> </div>
  </section>

<div class="container">
 
  <!-- Navigation -->
  <header> <a href="">
    <h4 class="logo"></h4>
    </a>
    <nav>
      <ul>
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutUs.php">ABOUT US</a></li>
        <li><a href="get-records.php">RECORDS</a></li>
        <li> <a href="contact.php">CONTACT</a></li>
      </ul>
    </nav>
  </header>


<div id="search">

<form  method="post" action="get-records.php?go"  id="searchform"> 
<input  type="text" name="artistName"> 
<input  type="submit" name="submit" value="Search"> 
</form> 
</div>
<?php 

     if(isset($_POST['submit'])){ 
        $artistName = $_POST['artistName'];
     if(isset($_GET['go'])){ 
     if(preg_match("/^[A-Za-z]+/", $_POST['artistName'])){

      include 'include/connect.php';
      
     $sql = "SELECT artistName, albumName, albumID, cost FROM album inner join artist on album.artistID = artist.artistID WHERE artistName LIKE '%" .$artistName. "%'";
     $result = $con->query($sql);
     echo '<table><tr><th>Artist</th><th>Album</th><th>Cost</th><th>Purchase</th></tr>'; 
        
        while ($row = $result->fetch_array()) {   

        $albumName=$row['albumName'];
        $cost=$row['cost'];
        $albumID=$row['albumID'];

        echo '<tr>';
        echo '<td>' . $artistName . '</td>';  
        echo '<td>' . $albumName . '</td>';
        echo '<td>' . $cost . '</td>';
        echo '<td><a href="delete-album.php?id=' . $albumID.'">BUY</a></td>';
    }
    echo "</table>"; 
   }
   }
  }

  //var_dump($_POST);

  ?> 

</div>
</div>
</body>


<!-- Footer Section -->
<?php include 'footer.html' ?>
<!-- Main Container Ends -->
</html>