<?php include 'include/mysqli.php' ?>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Dogs Table</title>
</head>
<body>
    <main>
        <h1>Wow. Much table. Very dog. <img src="http://i.imgur.com/Lz8IYdN.jpg" alt="Shibe Dog""></h1>
        <?php include 'include/submit-form.php' ?>
        <?php include 'dogs-form.php' ?>
		<?php include 'include/get-dogs.php' ?>
    </main>
</body>
</html>