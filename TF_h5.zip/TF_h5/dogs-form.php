
<!--This is the form for the user -->
   
<?php
    $formName = '';
    $formAge = '';
    $formBreed = '';

//Storing name
if (isset($_POST['name'])){
        $formName = $_POST['name'];
    }
else {
    if (isset($dog)) {
            $formName = $dog->dog_name;
        }
    }

//Storing age
if (isset($_POST['age'])){
        $formAge = $_POST['age'];
    }
else {
    if (isset($dog)) {
            $formAge = $dog->age;
        }
    }

//Storing breed
if (isset($_POST['breed'])){
        $formBreed = $_POST['breed'];
    }
else {
    if (isset($dog)) {
            $formBreed = $dog->breed_id;
        }
    }             
?>
        <form action="" method="post">
        	<fieldset>
                <select name="breed">	
             	<?php
             		$breeds = $con->query('select * from breeds');
                    foreach($breeds as $breed) {
                        $id = $breed['breed_id'];
                        $text = $breed['breed_name'];
                        //If the breed id is not in the post it will default to the first breed.
                        //If we have a selection, that is shown.
                        $selected = $id == $formBreed ? 'selected' : '';
                        echo "<option value=\"$id\" $selected>  $text</option>";
                    }
             	?>

                <input type="Text" name="name"
                 placeholder = "Dog name"
                 value="<?= isset($formName) ? $formName : '' ?>">
                 <!-- value is what we have in the post for $formName.
                 If nothing is in the post, value is empty string -->
                    
                <input type="number" name="age"
                 placeholder = "Age of dog"
                 value="<?= isset($formAge) ? $formAge : '' ?>">
                 <!-- value is what we have in the post for $formAge.
                 If nothing is in the post, value is empty/null -->

                <text> Fixed </text>   
                <input type = "checkbox" name="fixed" >

 				<text> Vaccinated </text>
                <input type = "checkbox" name ="vacc" > 
                    
                <input type="submit" value="Save">
            </fieldset>
        </form> 