<!-- Updates the database if you want to edit your dog info  -->

<?php include 'include/mysqli.php' ?>
<link rel="stylesheet" type="text/css" href="style.css">
<?php
$id = $_GET['id'];
$result = $con->query("select * from dogs where dog_id = $id");
if (!$result) {
	echo "<p class\"error\">$con->error</p>";
}
else{
	$dog = $result->fetch_object();
}

?>

<main>
    <h1>Wow. Much table. Very dog. <img src="http://i.imgur.com/Lz8IYdN.jpg" alt="Shibe Dog""></h1></h1>
    <?php include 'include/submit-form.php' ?>
    <?php include 'dogs-form.php' ?>
    <?php include 'include/get-dogs.php' ?>
</main>