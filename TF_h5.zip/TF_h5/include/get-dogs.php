<!-- Populates the table with the data  -->
<?php

$result = $con->query('select * from dogs left join breeds on dogs.breed_id = breeds.breed_id');
    echo '<table><tr><th>Breed</th><th>Name</th><th>Age</th><th>Fixed</th><th>Vaccinated</th><th>Action</th></tr>';
		
		while ($row = $result->fetch_object()) {

		echo '<tr>';
    	echo '<td>' . $row->breed_name . '</td>';	
    	echo '<td>' . $row->dog_name . '</td>';
    	echo '<td>' . $row->age . '</td>';
    	echo '<td>' . ($row->is_fixed ? 'yes' : 'no'). '</td>';
    	echo '<td>' . ($row->is_vaccinated ? 'yes' : 'no').' </td>';
    	echo '<td><a href="delete-dog.php?id=' . $row->dog_id .
        '">DELETE</a></td>';
        echo '<td><a href="edit-dog.php?id=' . $row->dog_id .
        '">EDIT</a></td>';
   		echo '</tr>';
	}
	echo "</table>";   

?>