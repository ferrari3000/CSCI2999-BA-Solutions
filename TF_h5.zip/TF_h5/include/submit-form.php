<!-- Sends the data to the server and provides error handling  -->
<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $breed = $_POST['breed'];
    $name = $_POST['name'];
    $age = $_POST['age']; 

    //Both $fixed and $vacc set to 1 if checked or 0 if not
    $fixed = isset($_POST['fixed']) ? 1 : 0;
    $vacc = isset($_POST['vacc']) ? 1 : 0;

    //error handling and form
    try {
        if (empty($name) || empty($age) || empty($breed)) {
            throw new Exception(
                "All Fields Required");
        }

        if (isset($dog)) {
            $id = $dog->dog_id;

       $q = "update dogs set dog_name = '$name',
                age = $age, is_fixed = $fixed, is_vaccinated = $vacc, breed_id = $breed where dog_id = $id";   
            }
        else{

        $q = "insert dogs (dog_name, age, is_fixed, is_vaccinated, breed_id)
            values ('$name', $age, $fixed, $vacc, $breed)";
        }

        $result = $con->query($q);
        if (!$result) {
            throw new Exception($con->error);
        }

         header('Location:index.php');
    } catch(Exception $e) {
        echo '<p class ="error">Error: ' .
        $e->getMessage() . '</p>';
    }
}
?>