<!-- Deletes data from the server based on the dog id number  -->

<?php
	include 'include/mysqli.php';
    $id = $_GET['id'];
    $q = "delete from dogs where dog_id = $id";
    $result = $con->query($q);

    if (!$result) {
    	echo "ERROR: " . $con->error;
    }
    else{
    	header('Location: index.php');
    }

?>